var searchData=
[
  ['enemy',['enemy',['../structenemy.html',1,'']]]
];
