/**
* @brief rotation avec souris  .
* @author Manar Sebri
* @param clip
* @param LI
* @param HI
* @param main



* @return Nothing
*/
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<time.h>
#include"SDL/SDL.h"
#include"SDL/SDL_image.h"
#include"SDL/SDL_mixer.h"
#include"game.h"

int  main(int argc, char *argv[])
{





enemy E;


 initialiser_enemy(&E);
   


 rotation_enemy( E);






}
